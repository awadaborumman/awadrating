import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';

class Rating extends StatefulWidget {
  bool isLiked;
  List<String> comments;

  Rating({this.isLiked, this.comments});

  @override
  _RatingState createState() => _RatingState();
}

class _RatingState extends State<Rating> {
  @override
  Widget build(BuildContext context) {
    double rating = 3.5;
    int starCount = 5;
    TextEditingController commentController = TextEditingController();
    void addComment() {
      if (commentController.text.isNotEmpty) {
        setState(() {
          widget.comments.add(commentController.text);
        });
      }
    }

    void toggleLike() {
      setState(() {
        widget.isLiked = !widget.isLiked;
      });
    }

    return Scaffold(
      appBar: AppBar(
        title: Text("Star Rating"),
      ),
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: <Widget>[
              Padding(
                padding: new EdgeInsets.only(
                  top: 50.0,
                  bottom: 20.0,
                ),
                child: Center(
                  child: SmoothStarRating(
                    allowHalfRating: true,
                    size: MediaQuery.of(context).size.width * 0.15,
                    rating: rating,
                    color: Colors.blueGrey,
                    borderColor: Colors.blueGrey,
                    starCount: starCount,
                    onRated: (rating) => setState(
                      () {
                        rating = rating;
                      },
                    ),
                  ),
                ),
              ),
              Card(
                child: Image.network(
                    "https://images.memphistours.com/large/778927933_as%20salt2.jpg"),
              ),
              ...widget.comments.map((e) => Text(e)).toList(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Container(
                    width: MediaQuery.of(context).size.width * 0.6,
                    padding: EdgeInsets.only(left: 10, right: 10),
                    child: TextFormField(
                      decoration: InputDecoration(
                        hintText: 'test comment',
                      ),
                      controller: commentController,
                    ),
                  ),
                  FlatButton(
                    onPressed: () {
                      addComment();
                    },
                    child: Text('Send'),
                  ),
                  IconButton(
                    onPressed: () {
                      toggleLike();
                    },
                    icon: Icon(Icons.thumb_up),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
