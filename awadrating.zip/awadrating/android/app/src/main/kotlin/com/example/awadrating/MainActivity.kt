package com.example.awadrating

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
